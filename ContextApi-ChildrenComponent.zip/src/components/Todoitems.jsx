import PropTypes from "prop-types";
import Todoitem from "./Todoitem";
import { TodoItemsContext } from "../store/todo-items-store";
import { useContext } from "react";

const Todoitems = () => {
  const { todoItems } = useContext(TodoItemsContext);

  return (
    <div className="iteam">
      {todoItems.map((item) => (
        <Todoitem
          key={item.name}
          todoName={item.name}
          todoDate={item.dueDate}
        ></Todoitem>
      ))}
    </div>
  );
};

Todoitems.propTypes = {
  todoItems: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      dueDate: PropTypes.string.isRequired,
    })
  ).isRequired,
};

export default Todoitems;
