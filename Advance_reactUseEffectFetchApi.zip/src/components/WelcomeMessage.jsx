const WelcomeMessage = () => {
  return (
    <center className="welcome-message">
      
      <h1>There are no posts created.</h1>
      
    </center>
  );
};

export default WelcomeMessage;
