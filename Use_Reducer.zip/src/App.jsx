import Appname from "./components/Appname";
import Addtodo from "./components/Addtodo";
import Todoitems from "./components/Todoitems";
import WelcomeMessage from "./components/WelcomeMessage";
import TodoItemsContextProvider from "./store/todo-items-store";

function App() {
  return (
    <TodoItemsContextProvider>
      <center className="todo-container">
        <Appname />
        <Addtodo />
        <WelcomeMessage />
        <Todoitems />
      </center>
    </TodoItemsContextProvider>
  );
}

export default App;
