import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "../Header";
import Footer from "../Footer";
import Sidebar from "../Sidebar";
import CreatePost from "../CreatePost";
import PostList from "../PostList";
import { useState } from "react";
import PostListProvider from "../../store/post-list-store";
import { Outlet } from "react-router-dom";

function App() {
  const [SelectedTab, setSelectedTab] = useState("Home");

 

  return (
    <PostListProvider>
    <div className="app-container">
      <Sidebar
        SelectedTab={ SelectedTab }
        setSelectedTab={setSelectedTab}
      ></Sidebar>
      <div className="content">
        <Header></Header>
        <Outlet/>

        <Footer></Footer>
      </div>
    </div>
    </PostListProvider>
  );
}

export default App;
