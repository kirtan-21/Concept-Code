import styles from "./WelcomeMessage.module.css"

const WelcomeMessage = () => {
    return <p className={styles.welcome} >Enjoy your Day. <br /> All task is completed.</p>
}

export default WelcomeMessage;