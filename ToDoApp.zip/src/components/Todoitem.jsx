import PropTypes from "prop-types";
import { IoCheckmarkDoneCircle } from "react-icons/io5";

function Todoitem({ todoName, todoDate, onDeleteClick }) {
  return (
    <div className="container">
      <div className="row kg-row">
        <div className="col-6">{todoName}</div>
        <div className="col-4">{todoDate}</div>
        <div
          className="col-2"
          style={{ display: "flex", justifyContent: "center" }}
        >
          <button
            type="button"
            className="btn btn-danger kg-button"
            onClick={() => onDeleteClick(todoName)}
          >
            <IoCheckmarkDoneCircle />
          </button>
        </div>
      </div>
    </div>
  );
}

Todoitem.propTypes = {
  todoName: PropTypes.string.isRequired,
  todoDate: PropTypes.string.isRequired,
  onDeleteClick: PropTypes.string.isRequired,
};

export default Todoitem;
