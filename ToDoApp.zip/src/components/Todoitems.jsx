import PropTypes from "prop-types";
import Todoitem from "./Todoitem";

const Todoitems = ({ todoItems, onDeleteClick }) => {
  return (
    <div className="iteam">
      {todoItems.map((item) => (
        <Todoitem  
        key={item.name}
        todoName={item.name}
        todoDate={item.dueDate} onDeleteClick={ onDeleteClick} ></Todoitem>
      ))}
    </div>
  );
};

Todoitems.propTypes = {
  todoItems: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      dueDate: PropTypes.string.isRequired,
      
    })
  ).isRequired,
};

export default Todoitems;
