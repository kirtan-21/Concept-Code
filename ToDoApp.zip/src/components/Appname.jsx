import styles from "./Appname.module.css"
function Appname() {
  return <h1 className={styles.todoHeading}> ToDo React App</h1>;
}

export default Appname;
