import Appname from "./components/Appname";
import Addtodo from "./components/Addtodo";
import Todoitems from "./components/Todoitems";
import { useState } from "react";
import WelcomeMessage from "./components/WelcomeMessage";

function App() {
  const [todoItems, settodoItems] = useState([
    { name: "Buy Milk", dueDate: "4/10/2023" },
    { name: "Go to College", dueDate: "26/10/2023" },
    { name: "Cheez", dueDate: "now" },
    { name: "ghee", dueDate: "Now" },
  ]);

  const handleNewItem = (itemName, itemDueDate) => {
    settodoItems((currVal) => [
      ...currVal,
      { name: itemName, dueDate: itemDueDate },
    ]);
  };

  const handleDeleteItem = (todoItemName) => {
    const newTodoItems = todoItems.filter((item) => item.name !== todoItemName);
    settodoItems(newTodoItems);
  };

  return (
    <center className="todo-container">
      <Appname />
      <Addtodo onNewItem={handleNewItem} />
      {todoItems.length === 0 && <WelcomeMessage></WelcomeMessage>}
      <Todoitems todoItems={todoItems} onDeleteClick={handleDeleteItem} />
    </center>
  );
}

export default App;
